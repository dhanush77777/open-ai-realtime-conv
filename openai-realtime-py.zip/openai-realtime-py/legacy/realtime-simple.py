import os
import threading
import pyaudio
import queue
import base64
import json
import time
from websocket import create_connection, WebSocketConnectionClosedException
from dotenv import load_dotenv
import logging
from typing import Optional, Dict, Any, List
from enum import Enum

class Language(Enum):
    """Supported languages with their codes"""
    ENGLISH = "en"
    SPANISH = "es"
    FRENCH = "fr"
    GERMAN = "de"
    ITALIAN = "it"
    PORTUGUESE = "pt"
    DUTCH = "nl"
    POLISH = "pl"
    HINDI = "hi"
    JAPANESE = "ja"
    KOREAN = "ko"
    CHINESE = "zh"
    RUSSIAN = "ru"
    ARABIC = "ar"
    TURKISH = "tr"
    INDONESIAN = "id"
    VIETNAMESE = "vi"
    THAI = "th"

class RealtimeConversation:
    def __init__(self, 
                 api_key: str, 
                 input_language: str = "en",
                 output_language: str = "en",
                 model: str = "gpt-4o-realtime-preview-2024-10-01"):
        """
        Initialize the conversation with specified languages.
        
        Args:
            api_key: OpenAI API key
            input_language: Language code for input speech (default: "en")
            output_language: Language code for output speech (default: "en")
            model: OpenAI model to use
        """
        self.CHUNK_SIZE = 1024
        self.RATE = 24000
        self.FORMAT = pyaudio.paInt16
        self.REENGAGE_DELAY_MS = 500
        
        self.api_key = api_key
        self.input_language = input_language
        self.output_language = output_language
        self.ws_url = f'wss://api.openai.com/v1/realtime?model={model}'
        
        self.audio_buffer = bytearray()
        self.mic_queue = queue.Queue()
        self.stop_event = threading.Event()
        
        self.mic_on_at = 0
        self.mic_active = None
        self.ws: Optional[create_connection] = None
        self.p = pyaudio.PyAudio()
        
        # Configure logging
        logging.basicConfig(level=logging.INFO, 
                          format='%(asctime)s [%(levelname)s] %(message)s')
        self.logger = logging.getLogger(__name__)

    @staticmethod
    def list_supported_languages() -> Dict[str, str]:
        """Return a dictionary of supported languages and their codes"""
        return {lang.name: lang.value for lang in Language}

    def set_languages(self, input_language: str = None, output_language: str = None):
        """Update input and output languages"""
        if input_language:
            if input_language not in [lang.value for lang in Language]:
                raise ValueError(f"Unsupported input language: {input_language}")
            self.input_language = input_language
            
        if output_language:
            if output_language not in [lang.value for lang in Language]:
                raise ValueError(f"Unsupported output language: {output_language}")
            self.output_language = output_language

    def mic_callback(self, in_data, frame_count, time_info, status):
        if time.time() > self.mic_on_at:
            if self.mic_active != True:
                self.logger.info('🎙️🟢 Mic active')
                self.mic_active = True
            self.mic_queue.put(in_data)
        else:
            if self.mic_active != False:
                self.logger.info('🎙️🔴 Mic suppressed')
                self.mic_active = False
        return (None, pyaudio.paContinue)

    def spkr_callback(self, in_data, frame_count, time_info, status):
        bytes_needed = frame_count * 2
        current_buffer_size = len(self.audio_buffer)

        if current_buffer_size >= bytes_needed:
            audio_chunk = bytes(self.audio_buffer[:bytes_needed])
            self.audio_buffer = self.audio_buffer[bytes_needed:]
            self.mic_on_at = time.time() + self.REENGAGE_DELAY_MS / 1000
        else:
            audio_chunk = bytes(self.audio_buffer) + b'\x00' * (bytes_needed - current_buffer_size)
            self.audio_buffer.clear()

        return (audio_chunk, pyaudio.paContinue)

    def send_mic_audio(self):
        try:
            while not self.stop_event.is_set():
                if not self.mic_queue.empty():
                    mic_chunk = self.mic_queue.get()
                    self.logger.info(f'🎤 Sending {len(mic_chunk)} bytes of audio data.')
                    encoded_chunk = base64.b64encode(mic_chunk).decode('utf-8')
                    message = json.dumps({
                        'type': 'input_audio_buffer.append', 
                        'audio': encoded_chunk
                    })
                    try:
                        self.ws.send(message)
                    except WebSocketConnectionClosedException:
                        self.logger.error('WebSocket connection closed.')
                        break
                    except Exception as e:
                        self.logger.error(f'Error sending mic audio: {e}')
        except Exception as e:
            self.logger.error(f'Exception in send_mic_audio thread: {e}')
        finally:
            self.logger.info('Exiting send_mic_audio thread.')

    def receive_audio(self):
        try:
            while not self.stop_event.is_set():
                try:
                    message = self.ws.recv()
                    if not message:
                        self.logger.info('🔵 Received empty message.')
                        break

                    message = json.loads(message)
                    event_type = message['type']
                    self.logger.info(f'⚡️ Received WebSocket event: {event_type}')

                    if event_type == 'response.audio.delta':
                        audio_content = base64.b64decode(message['delta'])
                        self.audio_buffer.extend(audio_content)
                        self.logger.info(
                            f'🔵 Received {len(audio_content)} bytes, '
                            f'total buffer size: {len(self.audio_buffer)}'
                        )
                    elif event_type == 'response.audio.done':
                        self.logger.info('🔵 AI finished speaking.')

                except WebSocketConnectionClosedException:
                    self.logger.error('WebSocket connection closed.')
                    break
                except Exception as e:
                    self.logger.error(f'Error receiving audio: {e}')
        except Exception as e:
            self.logger.error(f'Exception in receive_audio thread: {e}')
        finally:
            self.logger.info('Exiting receive_audio thread.')

    def setup_streams(self):
        self.mic_stream = self.p.open(
            format=self.FORMAT,
            channels=1,
            rate=self.RATE,
            input=True,
            stream_callback=self.mic_callback,
            frames_per_buffer=self.CHUNK_SIZE
        )

        self.spkr_stream = self.p.open(
            format=self.FORMAT,
            channels=1,
            rate=self.RATE,
            output=True,
            stream_callback=self.spkr_callback,
            frames_per_buffer=self.CHUNK_SIZE
        )

    def create_conversation_config(self, 
                                 system_prompt: str = None,
                                 instructions: str = None,
                                 conversation_style: Dict[str, Any] = None) -> Dict[str, Any]:
        """Create the configuration for the conversation including system prompts and language settings."""
        config = {
            'type': 'response.create',
            'response': {
                'modalities': ['audio', 'text'],
                'audio_config': {
                    'input': {
                        'language': self.input_language
                    },
                    'output': {
                        'language': self.output_language,
                        'model': 'tts-1'  # or any other TTS model you prefer
                    }
                }
            }
        }

        # Add messages if system prompt is provided
        if system_prompt:
            config['response']['messages'] = [
                {
                    'role': 'system',
                    'content': system_prompt
                }
            ]

        # Add instructions if provided
        if instructions:
            config['response']['instructions'] = instructions

        # Add conversation style if provided
        if conversation_style:
            config['response'].update(conversation_style)

        return config

    def connect(self, 
                system_prompt: str = None,
                instructions: str = None,
                conversation_style: Dict[str, Any] = None):
        try:
            self.ws = create_connection(
                self.ws_url,
                header=[
                    f'Authorization: Bearer {self.api_key}',
                    'OpenAI-Beta: realtime=v1'
                ]
            )
            self.logger.info(f'Connected to OpenAI WebSocket (Input: {self.input_language}, Output: {self.output_language})')

            config = self.create_conversation_config(
                system_prompt=system_prompt,
                instructions=instructions,
                conversation_style=conversation_style
            )

            self.ws.send(json.dumps(config))
            self.logger.info(f'Sent conversation configuration')

            receive_thread = threading.Thread(target=self.receive_audio)
            mic_thread = threading.Thread(target=self.send_mic_audio)
            
            receive_thread.start()
            mic_thread.start()

            while not self.stop_event.is_set():
                time.sleep(0.1)

            self.logger.info('Sending WebSocket close frame.')
            self.ws.send_close()

            receive_thread.join()
            mic_thread.join()

        except Exception as e:
            self.logger.error(f'Failed to connect to OpenAI: {e}')
        finally:
            if self.ws:
                try:
                    self.ws.close()
                    self.logger.info('WebSocket connection closed.')
                except Exception as e:
                    self.logger.error(f'Error closing WebSocket connection: {e}')

    def start(self, 
              system_prompt: str = None,
              instructions: str = None,
              conversation_style: Dict[str, Any] = None):
        self.setup_streams()
        try:
            self.mic_stream.start_stream()
            self.spkr_stream.start_stream()
            self.connect(
                system_prompt=system_prompt,
                instructions=instructions,
                conversation_style=conversation_style
            )
        except KeyboardInterrupt:
            self.logger.info('Gracefully shutting down...')
            self.stop_event.set()
        finally:
            self.cleanup()

def main():
    load_dotenv()
    api_key = os.getenv('OPENAI_API_KEY')
    
    # Clear console
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Example of using different languages
    system_prompt = """
- You are an AI Fitness coach.
- You need to answer the user's fitness-related questions only from the given knowledge base below.
- Types of Fitness
There are a few main components of fitness, all of which are important for building a well-rounded exercise routine. Below, you will find the ones included in the Physical Activity Guidelines for Americans, which HHS highlights as the components that should be included in weekly exercise. (It’s worth noting that many definitions of fitness include other components as well, such as endurance, muscular endurance, power, speed, balance, and agility — as mentioned above.) 

Aerobic (Cardiovascular) Exercise
Aerobic exercise is the foundation of every fitness program — and for good reason. Also called cardiovascular exercise or cardio, this type of physical activity increases your heart rate and breathing rate, which improves your cardiorespiratory fitness, according to the American Heart Association. 

Aerobic exercise includes activities like brisk walking, running, cycling, swimming, aerobic fitness classes (like kickboxing), tennis, dancing, yard work, tennis, and jumping rope, per the Physical Activity Guidelines.

Learn More About Aerobic Exercise

Strength Training
Strength training is an important way to improve mobility and overall functioning, particularly as you get older. “As you age, you lose muscle mass, which can have a significant impact on the quality of life. Strength exercises build bones and muscle, and more muscle protects your body from falls and the fractures that can happen in older age,” says Robert Sallis, MD, a family medicine doctor at Kaiser Permanente in Fontana, California, and chairman of the Exercise Is Medicine initiative with the American College of Sports Medicine (ACSM).

According to the ACSM, the definition of strength or resistance training is exercise that is “designed to improve muscular fitness by exercising a muscle or a muscle group against external resistance.” Activities that answer this call include lifting weights, using resistance bands or your body weight, carrying heavy loads, and even strenuous gardening, per the Physical Activity Guidelines from HHS. 

Learn More About Why Strength Training Is Important and How to Do It

Flexibility and Mobility
Flexibility and mobility are both important components of healthy movement, according to the International Sports Sciences Association. However, they are not synonymous. 

Flexibility refers to the ability of tendons, muscles, and ligaments to stretch, while mobility refers to the body’s ability to take a joint through its full range-of-motion. 

There is no specific recommendation for the number of minutes you should do activities that improve flexibility or mobility (such as stretching), and the health benefits of those activities are not known because of a lack of research on the topic, according to the Physical Activity Guidelines from HHS. But the guidelines note that flexibility exercises are important for physical fitness.

And the guidelines do recommend that older adults incorporate balance training into their weekly fitness routine. Evidence suggests that regular exercise that includes balance training can significantly reduce older adults’ risk of falls, which can cause serious and debilitating injuries, among other consequences.


"""
    
    conversation_style = {
        "temperature": 0.1,
        "max_tokens": 200
    }
    
    # Print available languages
    print("Available languages:")
    for name, code in RealtimeConversation.list_supported_languages().items():
        print(f"- {name}: {code}")
    
    # Example: Spanish input, English output
    conversation = RealtimeConversation(
        api_key=api_key,
        input_language="en",  # Spanish input
        output_language="en"  # English output
    )
    
    # You can also change languages after initialization
    # conversation.set_languages(input_language="fr", output_language="de")
    
    conversation.start(
        system_prompt=system_prompt,
        instructions= system_prompt+"Please do not deviate from the fitness-related knowledge base.And only speak in english , if you don't understand the language please ask the user to repeat the question in english.",
        conversation_style=conversation_style
    )

if __name__ == '__main__':
    main()