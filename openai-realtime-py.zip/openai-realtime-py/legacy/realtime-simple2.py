import os
os.system('cls' if os.name == 'nt' else 'clear')

import threading
import pyaudio
import queue
import base64
import json
import time
from websocket import create_connection, WebSocketConnectionClosedException
from dotenv import load_dotenv
import logging
knowledge_base = """
Aerobic exercise

Playing sports such as lawn tennis is a common way to maintain/improve physical fitness. Image shows international tennis player Barbora Strýcová.
Cardiorespiratory fitness can be measured using VO2 max, a measure of the amount of oxygen the body can uptake and utilize.[18][19] Aerobic exercise, which improves cardiorespiratory fitness and increase stamina, involves movement that increases the heart rate to improve the body's oxygen consumption. This form of exercise is an important part of all training regiments, whether for professional athletes or for the everyday person.[20]

Prominent examples of aerobic exercises include:

Jogging – Running at a steady and gentle pace. This form of exercise is great for maintaining weight and building a cardiovascular base to later perform more intense exercises.
Working on elliptical trainer – This is a stationary exercise machine used to perform walking, or running without causing excessive stress on the joints. This form of exercise is perfect for people with achy hips, knees, and ankles.
Walking – Moving at a fairly regular pace for a short, medium or long distance.
Treadmill training – Many treadmills have programs set up that offer numerous different workout plans. One effective cardiovascular activity would be to switch between running and walking. Typically warm up first by walking and then switch off between walking for three minutes and running for three minutes.
Swimming – Using the arms and legs to keep oneself afloat in water and moving either forwards or backward. This is a good full-body exercise for those who are looking to strengthen their core while improving cardiovascular endurance.
Cycling – Riding a bicycle typically involves longer distances than walking or jogging. This is another low-impact exercise on the joints and is great for improving leg strength.[21]

Anaerobic exercise
Main article: Anaerobic exercise


A man and a woman doing weight training at a health club
Anaerobic exercise features high-intensity movements performed in a short period of time. It is a fast, high-intensity exercise that does not require the body to utilize oxygen to produce energy. It helps to promote strength, endurance, speed, and power; and is used by bodybuilders to build workout intensity. Anaerobic exercises are thought to increase the metabolic rate, thereby allowing one to burn additional calories as the body recovers from exercise due to an increase in body temperature and excess post-exercise oxygen consumption (EPOC) after the exercise ended.

Prominent examples of anaerobic exercises include:

Weight training – A common type of strength training for developing the strength and size of skeletal muscles.
Isometric exercise – Helps to maintain strength. A muscle action in which no visible movement occurs and the resistance matches the muscular tension.[22]
Sprinting – Running short distances as fast as possible, training for muscle explosiveness.[23]
Interval training – Alternating short bursts (lasting around 30 seconds) of intense activity with longer intervals (three to four minutes) of less intense activity. This type of activity also builds speed and endurance.[24]

"""



logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

load_dotenv()

CHUNK_SIZE = 1024
RATE = 24000
FORMAT = pyaudio.paInt16
API_KEY = "sk-proj-7KjuzqtPCPINmb8XLKZcT3BlbkFJ5eDAkQBUzg05nx9kkkH9"
WS_URL = 'wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview-2024-10-01'

audio_buffer = bytearray()
mic_queue = queue.Queue()

stop_event = threading.Event()

mic_on_at = 0
mic_active = None
REENGAGE_DELAY_MS = 500


def mic_callback(in_data, frame_count, time_info, status):
    global mic_on_at, mic_active

    if time.time() > mic_on_at:
        if mic_active != True:
            logging.info('🎙️🟢 Mic active')
            mic_active = True
        mic_queue.put(in_data)
    else:
        if mic_active != False:
            logging.info('🎙️🔴 Mic suppressed')
            mic_active = False

    return (None, pyaudio.paContinue)


def send_mic_audio_to_websocket(ws):
    try:
        while not stop_event.is_set():
            if not mic_queue.empty():
                mic_chunk = mic_queue.get()
                logging.info(f'🎤 Sending {len(mic_chunk)} bytes of audio data.')
                encoded_chunk = base64.b64encode(mic_chunk).decode('utf-8')
                message = json.dumps({'type': 'input_audio_buffer.append', 'audio': encoded_chunk})
                try:
                    ws.send(message)
                except WebSocketConnectionClosedException:
                    logging.error('WebSocket connection closed.')
                    break
                except Exception as e:
                    logging.error(f'Error sending mic audio: {e}')
    except Exception as e:
        logging.error(f'Exception in send_mic_audio_to_websocket thread: {e}')
    finally:
        logging.info('Exiting send_mic_audio_to_websocket thread.')


def spkr_callback(in_data, frame_count, time_info, status):
    global audio_buffer, mic_on_at

    bytes_needed = frame_count * 2
    current_buffer_size = len(audio_buffer)

    if current_buffer_size >= bytes_needed:
        audio_chunk = bytes(audio_buffer[:bytes_needed])
        audio_buffer = audio_buffer[bytes_needed:]
        mic_on_at = time.time() + REENGAGE_DELAY_MS / 1000
    else:
        audio_chunk = bytes(audio_buffer) + b'\x00' * (bytes_needed - current_buffer_size)
        audio_buffer.clear()

    return (audio_chunk, pyaudio.paContinue)


def receive_audio_from_websocket(ws):
    global audio_buffer

    try:
        while not stop_event.is_set():
            try:
                message = ws.recv()
                if not message:  # Handle empty message (EOF or connection close)
                    logging.info('🔵 Received empty message (possibly EOF or WebSocket closing).')
                    break

                # Now handle valid JSON messages only
                message = json.loads(message)
                event_type = message['type']
                logging.info(f'⚡️ Received WebSocket event: {event_type}')

                if event_type == 'response.audio.delta':
                    audio_content = base64.b64decode(message['delta'])
                    audio_buffer.extend(audio_content)
                    logging.info(f'🔵 Received {len(audio_content)} bytes, total buffer size: {len(audio_buffer)}')

                elif event_type == 'response.audio.done':
                    logging.info('🔵 AI finished speaking.')

            except WebSocketConnectionClosedException:
                logging.error('WebSocket connection closed.')
                break
            except Exception as e:
                logging.error(f'Error receiving audio: {e}')
    except Exception as e:
        logging.error(f'Exception in receive_audio_from_websocket thread: {e}')
    finally:
        logging.info('Exiting receive_audio_from_websocket thread.')


def connect_to_openai():
    ws = None
    try:
        ws = create_connection(WS_URL, header=[f'Authorization: Bearer {API_KEY}', 'OpenAI-Beta: realtime=v1'])
        logging.info('Connected to OpenAI WebSocket.')

        # ws.send(json.dumps({
        #     'type': 'response.create',
        #     'response': {
        #         'modalities': ['text', 'audio'],
        #     #     'instructions': """Your name is alice , you handle the communication part between cobot and humans. cobot has
        #     #     only 3 functionalities namely:
        #     #     1.Detect objects : it uses the camera on its robotic arm to detect objects in front of it , if you give name of object
        #     #     it detects only that object 
        #     #     2.Picking objects : it can pickup objects its own way by just using this mode and the name of object 
        #     #     3. teaching new ways to pickup objects : if this mode is choosen it can see human demonistartion live and understand how to grasp the objects 
                
        #     #     so talk with users based on this and get the imformation required . dont talk extra or speak something which is not useful 
        #     # """}
        #         'instructions': """Only respond with words that rhyme with the last word of the user"""}
        # }))
        
        # ws.send(json.dumps({
        #     "event_id": 'event_setup_session',
        #     "type": 'session.update',
        #     "session": {
        #         "modalities": ['text', 'audio'],
        #         "instructions": '.',
        #         "voice": 'echo',
        #         "input_audio_format": 'pcm16',
        #         "output_audio_format": 'pcm16',
        #         "turn_detection": {
        #             "type": 'server_vad',
        #             "threshold": 0.5,
        #             "prefix_padding_ms": 300,
        #             "silence_duration_ms": 200
        #         }
        #     }
        # }))
        ws.send(json.dumps({
        "event_id": "event_setup_session",
        "type": "session.update",
        "session": {
            "modalities": ["text", "audio"],
            "instructions": f"""Your name is Alice. You are a friendly assistant who only talks in english and will be answering fitness related queries only from the below knowledge base .
            {knowledge_base}
            """,
            "voice": "echo",
            "input_audio_format": "pcm16",
            "output_audio_format": "pcm16",
            "turn_detection": {
                "type": "server_vad",
                "threshold": 0.5,
                "prefix_padding_ms": 300,
                "silence_duration_ms": 200
            }
        }
        # "tools": [
        #     {
        #     "name": 'set_memory',
        #     "description": 'Saves important data about the user into memory.',
        #     "parameters": {
        #     "type": 'object',
        #     "properties": {
        #         "key": {
        #         "type": 'string',
        #         "description":
        #             'The key of the memory value. Always use lowercase and underscores, no other characters.',
        #         },
        #         "value": {
        #         "type": 'string',
        #         "description": 'Value can be anything represented as a string',
        #         },
        #     },
        #     "required": ['key', 'value'],
        #     },
        # },
        # ]
    }))

        # Start the recv and send threads
        receive_thread = threading.Thread(target=receive_audio_from_websocket, args=(ws,))
        receive_thread.start()

        mic_thread = threading.Thread(target=send_mic_audio_to_websocket, args=(ws,))
        mic_thread.start()

        # Wait for stop_event to be set
        while not stop_event.is_set():
            time.sleep(0.1)

        # Send a close frame and close the WebSocket gracefully
        logging.info('Sending WebSocket close frame.')
        ws.send_close()

        receive_thread.join()
        mic_thread.join()

        logging.info('WebSocket closed and threads terminated.')
    except Exception as e:
        logging.error(f'Failed to connect to OpenAI: {e}')
    finally:
        if ws is not None:
            try:
                ws.close()
                logging.info('WebSocket connection closed.')
            except Exception as e:
                logging.error(f'Error closing WebSocket connection: {e}')


def main():
    p = pyaudio.PyAudio()

    mic_stream = p.open(
        format=FORMAT,
        channels=1,
        rate=RATE,
        input=True,
        stream_callback=mic_callback,
        frames_per_buffer=CHUNK_SIZE
    )

    spkr_stream = p.open(
        format=FORMAT,
        channels=1,
        rate=RATE,
        output=True,
        stream_callback=spkr_callback,
        frames_per_buffer=CHUNK_SIZE
    )

    try:
        mic_stream.start_stream()
        spkr_stream.start_stream()

        connect_to_openai()

        while mic_stream.is_active() and spkr_stream.is_active():
            time.sleep(0.1)

    except KeyboardInterrupt:
        logging.info('Gracefully shutting down...')
        stop_event.set()

    finally:
        mic_stream.stop_stream()
        mic_stream.close()
        spkr_stream.stop_stream()
        spkr_stream.close()

        p.terminate()
        logging.info('Audio streams stopped and resources released. Exiting.')


if __name__ == '__main__':
    main()